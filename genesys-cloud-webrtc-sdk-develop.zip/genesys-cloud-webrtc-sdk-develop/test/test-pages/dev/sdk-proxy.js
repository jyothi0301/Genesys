import { GenesysCloudWebrtcSdk as sdk } from '../../../src/client';

export let GenesysCloudWebrtcSdk = sdk;
