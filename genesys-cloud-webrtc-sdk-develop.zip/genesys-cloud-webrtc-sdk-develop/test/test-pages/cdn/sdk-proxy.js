export function getSdk () {
  return window.GenesysCloudWebrtcSdk.default;
}

export let GenesysCloudWebrtcSdk = null;
